export const GRAY = "#d5dde5"
export const BORDER_COLOR = GRAY
export const APP_BACKGROUND_COLOR = "#f3f5f7"
export const BLUE = '#5470c6'
export const BLUE_SECOND = '#118AB2'
export const GREEN = '#91cc75'
export const RED = '#ec6565'
export const ORANGE = '#fac858'
export const WHITE = '#FFFFFF'
export const BLACK = '#000000'
export const JAUNE = '#FFEA00'
export const WHITE_GREEN = '#06D6A0'
export const GRAY_DARK = '#b4b4b4'

// export const GRAY_DARK = '#E1E5F2'
// export const GRAY_DARK = '#e6e6e6'
// export const RED = '#EF476F'
// export const ORANGE = '#FF7B00'