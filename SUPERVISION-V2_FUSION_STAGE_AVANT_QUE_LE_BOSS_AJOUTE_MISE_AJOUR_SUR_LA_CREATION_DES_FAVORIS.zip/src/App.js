import React from 'react'
import Body from './components/Body'

import 'react-big-calendar/lib/css/react-big-calendar.css'
import 'antd/dist/reset.css'
import './App.css'


const App = () => <Body />

export default App