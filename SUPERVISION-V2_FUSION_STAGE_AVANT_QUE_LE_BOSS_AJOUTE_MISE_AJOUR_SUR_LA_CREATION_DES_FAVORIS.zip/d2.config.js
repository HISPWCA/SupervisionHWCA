const config = {
      type: 'app',
      name: 'Supervision-v2',
      title: 'Supervision-v2',
      description: 'Supervision-v2 App  ',
      entryPoints: {
            app: './src/App.js'
      }
};

module.exports = config
