## Fonctionalitées

- Module de dashboard
- Module de planification
- Module de configuration